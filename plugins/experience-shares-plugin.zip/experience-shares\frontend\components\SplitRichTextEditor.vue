<template>
  <div class="split-rich-text-editor" :class="{ 'is-disabled': disabled }">
    <div class="toolbar" role="toolbar" aria-label="简介编辑工具栏">
      <el-tooltip
        v-for="action in toolbarActions"
        :key="action.key"
        :content="action.title"
        placement="top"
        :show-after="150"
      >
        <button
          type="button"
          class="toolbar-button"
          :aria-label="action.title"
          :disabled="disabled"
          @mousedown.prevent
          @click="handleAction(action)"
        >
          <component :is="action.icon" v-if="action.icon" class="toolbar-icon" />
          <span v-else class="toolbar-glyph" :class="action.glyphClass">{{ action.label }}</span>
        </button>
      </el-tooltip>
    </div>

    <div class="workspace">
      <div class="editor-pane">
        <div class="pane-header">
          <span class="pane-title">编辑源码</span>
          <span class="pane-subtitle">左侧保持纯文本，工具栏插入 HTML 标签</span>
        </div>
        <div v-if="isEmpty && placeholder" class="editor-placeholder-hint">
          {{ placeholder }}
        </div>
        <textarea
          ref="editorRef"
          class="editor-textarea"
          :value="modelValue"
          :disabled="disabled"
          spellcheck="false"
          @focus="handleFocus"
          @blur="handleBlur"
          @input="handleInput"
          @keyup="saveSelection"
          @click="saveSelection"
          @select="saveSelection"
        ></textarea>
      </div>

      <div class="preview-pane">
        <div class="pane-header">
          <span class="pane-title">实时预览</span>
          <span class="pane-subtitle">右侧会渲染左侧源码内容</span>
        </div>
        <div class="preview-body">
          <MarkdownRenderer v-if="hasContent" :content="modelValue" />
          <div v-else class="preview-empty">简介内容会实时渲染在这里</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, markRaw, nextTick, ref, watch } from 'vue'
import {
  Back,
  Brush,
  ChatLineSquare,
  Delete,
  Grid,
  Link,
  List,
  Operation,
  Picture,
  RefreshLeft,
  RefreshRight,
  Right,
  Tickets
} from '@element-plus/icons-vue'
import MarkdownRenderer from '@/components/MarkdownRenderer.vue'

type ToolbarAction = {
  key: string
  label: string
  title: string
  icon?: object
  glyphClass?: string
}

const props = withDefaults(defineProps<{
  modelValue: string
  placeholder?: string
  disabled?: boolean
}>(), {
  placeholder: '请输入简介内容',
  disabled: false
})

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
}>()

const editorRef = ref<HTMLTextAreaElement | null>(null)
const savedSelection = ref({ start: 0, end: 0 })
const history = ref<string[]>([])
const historyIndex = ref(-1)
const isApplyingHistory = ref(false)

const toolbarActions: ToolbarAction[] = [
  { key: 'bold', label: 'B', title: '粗体' },
  { key: 'italic', label: 'I', title: '斜体' },
  { key: 'h1', label: 'H1', title: '一级标题' },
  { key: 'h2', label: 'H2', title: '二级标题' },
  { key: 'underline', label: 'U', title: '下划线' },
  { key: 'strike', label: 'S', title: '删除线', glyphClass: 'is-strike' },
  { key: 'quote', label: '', title: '引用', icon: markRaw(ChatLineSquare) },
  { key: 'sup', label: 'x2', title: '上标' },
  { key: 'sub', label: 'x_', title: '下标' },
  { key: 'left', label: '', title: '左对齐', icon: markRaw(Back) },
  { key: 'center', label: '', title: '居中', icon: markRaw(Operation) },
  { key: 'right', label: '', title: '右对齐', icon: markRaw(Right) },
  { key: 'ul', label: '', title: '无序列表', icon: markRaw(List) },
  { key: 'ol', label: '', title: '有序列表', icon: markRaw(Tickets) },
  { key: 'link', label: '', title: '插入链接', icon: markRaw(Link) },
  { key: 'image', label: '', title: '插入图片', icon: markRaw(Picture) },
  { key: 'code', label: '</>', title: '代码' },
  { key: 'table', label: '', title: '插入表格', icon: markRaw(Grid) },
  { key: 'undo', label: '', title: '撤销', icon: markRaw(RefreshLeft) },
  { key: 'redo', label: '', title: '重做', icon: markRaw(RefreshRight) },
  { key: 'delete', label: '', title: '删除选中内容', icon: markRaw(Delete) },
  { key: 'clear', label: '', title: '清除格式', icon: markRaw(Brush) }
]

const isEmpty = computed(() => !(props.modelValue || '').trim())
const hasContent = computed(() => Boolean((props.modelValue || '').trim()))

const escapeHtml = (value: string) =>
  value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')

const pushHistory = (value: string) => {
  if (historyIndex.value >= 0 && history.value[historyIndex.value] === value) return

  const nextHistory = history.value.slice(0, historyIndex.value + 1)
  nextHistory.push(value)

  if (nextHistory.length > 100) {
    nextHistory.shift()
  }

  history.value = nextHistory
  historyIndex.value = history.value.length - 1
}

watch(
  () => props.modelValue || '',
  value => {
    if (isApplyingHistory.value) {
      isApplyingHistory.value = false
      return
    }
    pushHistory(value)
  },
  { immediate: true }
)

const saveSelection = () => {
  if (!editorRef.value) return
  savedSelection.value = {
    start: editorRef.value.selectionStart ?? 0,
    end: editorRef.value.selectionEnd ?? 0
  }
}

const focusEditor = async (start = savedSelection.value.start, end = savedSelection.value.end) => {
  await nextTick()
  if (!editorRef.value) return
  editorRef.value.focus()
  editorRef.value.setSelectionRange(start, end)
  savedSelection.value = { start, end }
}

const updateValue = (value: string, selectionStart: number, selectionEnd: number) => {
  emit('update:modelValue', value)
  void focusEditor(selectionStart, selectionEnd)
}

const getSelectionRange = () => {
  if (!editorRef.value) {
    return savedSelection.value
  }

  return {
    start: editorRef.value.selectionStart ?? savedSelection.value.start,
    end: editorRef.value.selectionEnd ?? savedSelection.value.end
  }
}

const replaceSelection = (
  inserted: string,
  selectionStart: number,
  selectionEnd: number,
  nextSelectionStart = selectionStart + inserted.length,
  nextSelectionEnd = nextSelectionStart
) => {
  const currentValue = props.modelValue || ''
  const nextValue =
    currentValue.slice(0, selectionStart) +
    inserted +
    currentValue.slice(selectionEnd)

  updateValue(nextValue, nextSelectionStart, nextSelectionEnd)
}

const wrapSelection = (
  prefix: string,
  suffix: string,
  placeholder: string,
  transformSelected?: (value: string) => string
) => {
  const { start, end } = getSelectionRange()
  const currentValue = props.modelValue || ''
  const selectedText = currentValue.slice(start, end)
  const content = selectedText
    ? transformSelected
      ? transformSelected(selectedText)
      : selectedText
    : placeholder
  const inserted = `${prefix}${content}${suffix}`

  if (selectedText) {
    replaceSelection(inserted, start, end)
    return
  }

  replaceSelection(
    inserted,
    start,
    end,
    start + prefix.length,
    start + prefix.length + content.length
  )
}

const insertHeading = (level: 'h1' | 'h2') => {
  wrapSelection(`<${level}>`, `</${level}>`, '标题')
}

const insertQuote = () => {
  wrapSelection('<blockquote>', '</blockquote>', '引用内容')
}

const insertCode = () => {
  const { start, end } = getSelectionRange()
  const currentValue = props.modelValue || ''
  const selectedText = currentValue.slice(start, end)
  const content = selectedText || '代码内容'
  const escaped = escapeHtml(content)
  const inserted = content.includes('\n')
    ? `<pre><code>${escaped}</code></pre>`
    : `<code>${escaped}</code>`

  if (selectedText) {
    replaceSelection(inserted, start, end)
    return
  }

  replaceSelection(inserted, start, end)
}

const insertLink = () => {
  const url = window.prompt('请输入链接地址')?.trim()
  if (!url) return

  const { start, end } = getSelectionRange()
  const currentValue = props.modelValue || ''
  const selectedText = currentValue.slice(start, end)
  const text = selectedText || window.prompt('请输入链接文本')?.trim() || url
  const escapedText = escapeHtml(text)
  const inserted =
    `<a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">` +
    `${escapedText}</a>`

  if (selectedText) {
    replaceSelection(inserted, start, end)
    return
  }

  const textStart = start + inserted.indexOf(escapedText)
  replaceSelection(inserted, start, end, textStart, textStart + escapedText.length)
}

const insertImage = () => {
  const url = window.prompt('请输入图片地址')?.trim()
  if (!url) return

  const alt = window.prompt('请输入图片说明（可选）')?.trim() || 'image'
  const { start, end } = getSelectionRange()
  const inserted = `<img src="${escapeHtml(url)}" alt="${escapeHtml(alt)}" />`
  replaceSelection(inserted, start, end)
}

const insertTable = () => {
  const rows = Number.parseInt(window.prompt('表格行数', '2') || '2', 10)
  const cols = Number.parseInt(window.prompt('表格列数', '3') || '3', 10)

  const safeRows = Number.isFinite(rows) && rows > 0 ? Math.min(rows, 10) : 2
  const safeCols = Number.isFinite(cols) && cols > 0 ? Math.min(cols, 8) : 3

  const header = Array.from({ length: safeCols }, (_, index) => `<th>标题${index + 1}</th>`).join('')
  const body = Array.from(
    { length: Math.max(safeRows - 1, 1) },
    () => `<tr>${Array.from({ length: safeCols }, () => '<td>内容</td>').join('')}</tr>`
  ).join('')
  const { start, end } = getSelectionRange()
  const inserted = `<table><thead><tr>${header}</tr></thead><tbody>${body}</tbody></table>`
  replaceSelection(inserted, start, end)
}

const insertList = (ordered: boolean) => {
  const { start, end } = getSelectionRange()
  const currentValue = props.modelValue || ''
  const selectedText = currentValue.slice(start, end).trim()
  const items = selectedText
    ? selectedText.split(/\r?\n/).filter(Boolean)
    : ['列表项']
  const tag = ordered ? 'ol' : 'ul'
  const inserted = `<${tag}>\n${items.map(item => `  <li>${escapeHtml(item)}</li>`).join('\n')}\n</${tag}>`
  replaceSelection(inserted, start, end)
}

const insertAlignedBlock = (align: 'left' | 'center' | 'right') => {
  wrapSelection(`<div style="text-align:${align};">`, '</div>', '段落内容')
}

const clearFormatting = () => {
  const { start, end } = getSelectionRange()
  const currentValue = props.modelValue || ''
  const hasSelection = start !== end
  const target = hasSelection ? currentValue.slice(start, end) : currentValue
  const stripped = target
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")

  if (hasSelection) {
    replaceSelection(stripped, start, end)
    return
  }

  updateValue(stripped, 0, 0)
}

const deleteContent = () => {
  const { start, end } = getSelectionRange()

  if (start !== end) {
    replaceSelection('', start, end, start, start)
    return
  }

  updateValue('', 0, 0)
}

const applyHistory = (nextIndex: number) => {
  if (nextIndex < 0 || nextIndex >= history.value.length) return
  historyIndex.value = nextIndex
  isApplyingHistory.value = true
  emit('update:modelValue', history.value[nextIndex])
  void focusEditor(0, 0)
}

const undo = () => {
  applyHistory(historyIndex.value - 1)
}

const redo = () => {
  applyHistory(historyIndex.value + 1)
}

const handleAction = (action: ToolbarAction) => {
  if (props.disabled) return

  switch (action.key) {
    case 'bold':
      wrapSelection('<strong>', '</strong>', '粗体文本')
      break
    case 'italic':
      wrapSelection('<em>', '</em>', '斜体文本')
      break
    case 'h1':
      insertHeading('h1')
      break
    case 'h2':
      insertHeading('h2')
      break
    case 'underline':
      wrapSelection('<u>', '</u>', '下划线文本')
      break
    case 'strike':
      wrapSelection('<s>', '</s>', '删除线文本')
      break
    case 'quote':
      insertQuote()
      break
    case 'sup':
      wrapSelection('<sup>', '</sup>', '上标')
      break
    case 'sub':
      wrapSelection('<sub>', '</sub>', '下标')
      break
    case 'left':
      insertAlignedBlock('left')
      break
    case 'center':
      insertAlignedBlock('center')
      break
    case 'right':
      insertAlignedBlock('right')
      break
    case 'ul':
      insertList(false)
      break
    case 'ol':
      insertList(true)
      break
    case 'link':
      insertLink()
      break
    case 'image':
      insertImage()
      break
    case 'code':
      insertCode()
      break
    case 'table':
      insertTable()
      break
    case 'undo':
      undo()
      break
    case 'redo':
      redo()
      break
    case 'delete':
      deleteContent()
      break
    case 'clear':
      clearFormatting()
      break
    default:
      break
  }
}

const handleInput = (event: Event) => {
  const target = event.target as HTMLTextAreaElement
  emit('update:modelValue', target.value)
  saveSelection()
}

const handleFocus = () => {
  saveSelection()
}

const handleBlur = () => {
  saveSelection()
}
</script>

<style scoped>
.split-rich-text-editor {
  border: 1px solid var(--el-border-color);
  border-radius: 16px;
  background: #fff;
  overflow: hidden;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.split-rich-text-editor:focus-within {
  border-color: var(--el-color-primary);
  box-shadow: 0 0 0 1px rgba(64, 158, 255, 0.15);
}

.toolbar {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding: 12px;
  border-bottom: 1px solid rgba(148, 163, 184, 0.16);
  background: linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%);
}

.toolbar-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 42px;
  height: 34px;
  padding: 0 10px;
  border: 1px solid rgba(148, 163, 184, 0.2);
  border-radius: 10px;
  background: #fff;
  color: #334155;
  font-size: 12px;
  font-weight: 700;
  line-height: 1;
  cursor: pointer;
  transition: all 0.2s ease;
}

.toolbar-icon {
  width: 15px;
  height: 15px;
}

.toolbar-glyph {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 16px;
  font-size: 12px;
  font-weight: 700;
  line-height: 1;
}

.toolbar-glyph.is-strike {
  text-decoration: line-through;
}

.toolbar-button:hover:not(:disabled) {
  border-color: rgba(64, 158, 255, 0.35);
  color: #2563eb;
  transform: translateY(-1px);
}

.toolbar-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.workspace {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 0.95fr);
  min-height: 320px;
}

.editor-pane,
.preview-pane {
  min-width: 0;
  display: flex;
  flex-direction: column;
}

.editor-pane {
  border-right: 1px solid rgba(148, 163, 184, 0.16);
}

.pane-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  padding: 12px 14px;
  border-bottom: 1px solid rgba(148, 163, 184, 0.12);
  background: rgba(248, 250, 252, 0.75);
}

.pane-title {
  font-size: 13px;
  font-weight: 700;
  color: #1f2937;
}

.pane-subtitle {
  font-size: 12px;
  color: #64748b;
}

.editor-placeholder-hint {
  padding: 10px 16px 0;
  font-size: 12px;
  line-height: 1.6;
  color: #94a3b8;
}

.editor-textarea {
  width: 100%;
  min-height: 260px;
  padding: 16px;
  border: none;
  outline: none;
  resize: vertical;
  background: #fff;
  color: #1f2937;
  font-size: 14px;
  line-height: 1.75;
  font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
  box-sizing: border-box;
}

.preview-body {
  min-height: 260px;
  padding: 16px;
  background: linear-gradient(180deg, #fcfcfd 0%, #f8fafc 100%);
  overflow-y: auto;
}

.preview-empty {
  color: #94a3b8;
  font-size: 14px;
  line-height: 1.7;
}

.is-disabled {
  background: #f8fafc;
}

.is-disabled .editor-textarea,
.is-disabled .preview-body {
  color: #94a3b8;
}

@media (max-width: 960px) {
  .workspace {
    grid-template-columns: 1fr;
  }

  .editor-pane {
    border-right: none;
    border-bottom: 1px solid rgba(148, 163, 184, 0.16);
  }

  .pane-header {
    align-items: flex-start;
    flex-direction: column;
  }
}
</style>
